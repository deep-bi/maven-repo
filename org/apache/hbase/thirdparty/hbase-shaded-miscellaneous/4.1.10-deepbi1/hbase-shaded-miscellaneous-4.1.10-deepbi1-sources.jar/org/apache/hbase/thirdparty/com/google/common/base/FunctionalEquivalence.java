/*
 * Copyright (C) 2011 The Guava Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package org.apache.hbase.thirdparty.com.google.common.base;

import static org.apache.hbase.thirdparty.com.google.common.base.Preconditions.checkNotNull;

import org.apache.hbase.thirdparty.com.google.common.annotations.GwtCompatible;
import org.apache.hbase.thirdparty.com.google.common.annotations.GwtIncompatible;
import org.apache.hbase.thirdparty.com.google.common.annotations.J2ktIncompatible;
import java.io.Serializable;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

/**
 * Equivalence applied on functional result.
 *
 * @author Bob Lee
 * @since 10.0
 */
@GwtCompatible
final class FunctionalEquivalence<F, T> extends Equivalence<F> implements Serializable {

  @GwtIncompatible @J2ktIncompatible private static final long serialVersionUID = 0;

  private final Function<? super F, ? extends @Nullable T> function;
  private final Equivalence<T> resultEquivalence;

  FunctionalEquivalence(
      Function<? super F, ? extends @Nullable T> function, Equivalence<T> resultEquivalence) {
    this.function = checkNotNull(function);
    this.resultEquivalence = checkNotNull(resultEquivalence);
  }

  @Override
  protected boolean doEquivalent(F a, F b) {
    return resultEquivalence.equivalent(function.apply(a), function.apply(b));
  }

  @Override
  protected int doHash(F a) {
    return resultEquivalence.hash(function.apply(a));
  }

  @Override
  public boolean equals(@Nullable Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj instanceof FunctionalEquivalence) {
      FunctionalEquivalence<?, ?> that = (FunctionalEquivalence<?, ?>) obj;
      return function.equals(that.function) && resultEquivalence.equals(that.resultEquivalence);
    }
    return false;
  }

  @Override
  public int hashCode() {
    return Objects.hash(function, resultEquivalence);
  }

  @Override
  public String toString() {
    return resultEquivalence + ".onResultOf(" + function + ")";
  }
}
