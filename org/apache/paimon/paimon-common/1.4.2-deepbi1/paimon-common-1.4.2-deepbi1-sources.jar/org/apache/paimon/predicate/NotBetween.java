/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.predicate;

import org.apache.paimon.types.DataType;

import org.apache.paimon.shade.jackson2.com.fasterxml.jackson.annotation.JsonCreator;

import java.util.List;
import java.util.Optional;

import static org.apache.paimon.predicate.CompareUtils.compareLiteral;

/**
 * The {@link LeafFunction} for not between. Now this is just an internal function as the negation
 * of {@link Between}.
 */
public class NotBetween extends LeafTernaryFunction {

    private static final long serialVersionUID = 1L;

    public static final String NAME = "NOT_BETWEEN";

    public static final NotBetween INSTANCE = new NotBetween();

    @JsonCreator
    public NotBetween() {}

    @Override
    public boolean test(DataType type, Object field, Object literal1, Object literal2) {
        return compareLiteral(type, literal1, field) > 0
                || compareLiteral(type, literal2, field) < 0;
    }

    @Override
    public boolean test(
            DataType type,
            long rowCount,
            Object min,
            Object max,
            Long nullCount,
            Object literal1,
            Object literal2) {
        return compareLiteral(type, literal1, min) > 0 || compareLiteral(type, literal2, max) < 0;
    }

    @Override
    public Optional<LeafFunction> negate() {
        return Optional.of(Between.INSTANCE);
    }

    @Override
    public <T> T visit(FunctionVisitor<T> visitor, FieldRef fieldRef, List<Object> literals) {
        return visitor.visitNotBetween(fieldRef, literals.get(0), literals.get(1));
    }

    @Override
    public String toJson() {
        return NAME;
    }
}
