/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.globalindex;

import org.apache.paimon.predicate.FullTextSearch;
import org.apache.paimon.predicate.FunctionVisitor;
import org.apache.paimon.predicate.LeafPredicate;
import org.apache.paimon.predicate.VectorSearch;

import java.io.Closeable;
import java.util.List;
import java.util.Optional;

/** Index reader for global index, return {@link GlobalIndexResult}. */
public interface GlobalIndexReader extends FunctionVisitor<Optional<GlobalIndexResult>>, Closeable {

    @Override
    default Optional<GlobalIndexResult> visitAnd(List<Optional<GlobalIndexResult>> children) {
        throw new UnsupportedOperationException();
    }

    @Override
    default Optional<GlobalIndexResult> visitOr(List<Optional<GlobalIndexResult>> children) {
        throw new UnsupportedOperationException();
    }

    @Override
    default Optional<GlobalIndexResult> visitNonFieldLeaf(LeafPredicate predicate) {
        throw new UnsupportedOperationException();
    }

    default Optional<ScoredGlobalIndexResult> visitVectorSearch(VectorSearch vectorSearch) {
        throw new UnsupportedOperationException();
    }

    default Optional<ScoredGlobalIndexResult> visitFullTextSearch(FullTextSearch fullTextSearch) {
        throw new UnsupportedOperationException();
    }
}
