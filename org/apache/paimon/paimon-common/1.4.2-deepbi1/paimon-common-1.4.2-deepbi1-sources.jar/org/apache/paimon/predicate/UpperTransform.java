/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.predicate;

import org.apache.paimon.data.BinaryString;

import org.apache.paimon.shade.jackson2.com.fasterxml.jackson.annotation.JsonCreator;
import org.apache.paimon.shade.jackson2.com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.paimon.shade.jackson2.com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.List;

import static org.apache.paimon.utils.Preconditions.checkArgument;

/** Upper {@link Transform}. */
public class UpperTransform extends StringTransform {

    private static final long serialVersionUID = 1L;

    public static final String NAME = "UPPER";

    @JsonCreator
    public UpperTransform(
            @JsonProperty(StringTransform.FIELD_INPUTS)
                    @JsonDeserialize(contentUsing = StringTransform.InputDeserializer.class)
                    List<Object> inputs) {
        super(inputs);
        checkArgument(inputs.size() == 1);
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public BinaryString transform(List<BinaryString> inputs) {
        BinaryString string = inputs.get(0);
        if (string == null) {
            return null;
        }
        return string.toUpperCase();
    }

    @Override
    public Transform copyWithNewInputs(List<Object> inputs) {
        return new UpperTransform(inputs);
    }
}
