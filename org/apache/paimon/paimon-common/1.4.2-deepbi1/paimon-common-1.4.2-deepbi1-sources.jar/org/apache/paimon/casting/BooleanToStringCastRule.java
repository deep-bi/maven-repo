/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.casting;

import org.apache.paimon.data.BinaryString;
import org.apache.paimon.types.DataType;
import org.apache.paimon.types.DataTypeFamily;
import org.apache.paimon.types.DataTypeRoot;
import org.apache.paimon.utils.BinaryStringUtils;

/** {@link DataTypeRoot#BOOLEAN} to {@link DataTypeFamily#CHARACTER_STRING} cast rule. */
class BooleanToStringCastRule extends AbstractCastRule<Boolean, BinaryString> {

    static final BooleanToStringCastRule INSTANCE = new BooleanToStringCastRule();

    private BooleanToStringCastRule() {
        super(
                CastRulePredicate.builder()
                        .input(DataTypeRoot.BOOLEAN)
                        .target(DataTypeFamily.CHARACTER_STRING)
                        .build());
    }

    @Override
    public CastExecutor<Boolean, BinaryString> create(DataType inputType, DataType targetType) {
        return value ->
                BinaryStringUtils.toCharacterString(
                        BinaryString.fromString(value.toString()), targetType);
    }
}
