/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.casting;

import org.apache.paimon.types.DataType;
import org.apache.paimon.types.DataTypeFamily;

/**
 * Cast rule for {@link DataTypeFamily#INTEGER_NUMERIC} and {@link
 * DataTypeFamily#APPROXIMATE_NUMERIC} conversions.
 */
class NumericPrimitiveCastRule extends AbstractCastRule<Number, Number> {

    static final NumericPrimitiveCastRule INSTANCE = new NumericPrimitiveCastRule();

    private NumericPrimitiveCastRule() {
        super(
                CastRulePredicate.builder()
                        .input(DataTypeFamily.INTEGER_NUMERIC)
                        .input(DataTypeFamily.APPROXIMATE_NUMERIC)
                        .target(DataTypeFamily.INTEGER_NUMERIC)
                        .target(DataTypeFamily.APPROXIMATE_NUMERIC)
                        .build());
    }

    @Override
    public CastExecutor<Number, Number> create(DataType inputType, DataType targetType) {
        switch (targetType.getTypeRoot()) {
            case TINYINT:
                return Number::byteValue;
            case SMALLINT:
                return Number::shortValue;
            case INTEGER:
                return Number::intValue;
            case BIGINT:
                return Number::longValue;
            case FLOAT:
                return Number::floatValue;
            case DOUBLE:
                return Number::doubleValue;
            default:
                return null;
        }
    }
}
