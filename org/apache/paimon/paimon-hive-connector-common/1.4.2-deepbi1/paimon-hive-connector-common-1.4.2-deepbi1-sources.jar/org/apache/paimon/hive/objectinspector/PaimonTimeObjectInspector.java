/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.hive.objectinspector;

import org.apache.paimon.utils.DateTimeUtils;

import org.apache.hadoop.hive.serde2.objectinspector.primitive.AbstractPrimitiveJavaObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfoFactory;
import org.apache.hadoop.io.Text;

/** {@link AbstractPrimitiveJavaObjectInspector} for TIME type. */
public class PaimonTimeObjectInspector extends AbstractPrimitiveJavaObjectInspector
        implements StringObjectInspector, WriteableObjectInspector {

    public PaimonTimeObjectInspector() {
        super(TypeInfoFactory.stringTypeInfo);
    }

    @Override
    public String getPrimitiveJavaObject(Object o) {
        if (o == null) {
            return null;
        }
        return DateTimeUtils.toLocalTime((int) o).toString();
    }

    @Override
    public Text getPrimitiveWritableObject(Object o) {
        return o == null ? null : new Text(getPrimitiveJavaObject(o));
    }

    @Override
    public Integer convert(Object value) {
        return value == null ? null : DateTimeUtils.parseTime((String) value);
    }
}
