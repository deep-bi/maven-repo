/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.jindodls;

import org.apache.paimon.fs.FileIO;
import org.apache.paimon.fs.FileIOLoader;
import org.apache.paimon.fs.Path;
import org.apache.paimon.jindo.JindoFileIO;

import java.util.ArrayList;
import java.util.List;

/** File loader for {@link JindoFileIO}. */
public class JindoDLSLoader implements FileIOLoader {

    @Override
    public List<String[]> requiredOptions() {
        return new ArrayList<>();
    }

    @Override
    public String getScheme() {
        return "dls";
    }

    @Override
    public FileIO load(Path path) {
        return new JindoFileIO();
    }
}
