// Generated from org.apache.spark.sql.catalyst.parser.extensions/PaimonSqlExtensions.g4 by ANTLR 4.9.3
package org.apache.spark.sql.catalyst.parser.extensions;
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PaimonSqlExtensionsLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.9.3", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, ALTER=7, AS=8, CALL=9, 
		CREATE=10, DAYS=11, DELETE=12, EXISTS=13, HOURS=14, IF=15, MINUTES=16, 
		NOT=17, OF=18, OR=19, RENAME=20, REPLACE=21, RETAIN=22, SHOW=23, TABLE=24, 
		TAG=25, TAGS=26, TO=27, VERSION=28, TRUE=29, FALSE=30, MAP=31, PLUS=32, 
		MINUS=33, STRING=34, BIGINT_LITERAL=35, SMALLINT_LITERAL=36, TINYINT_LITERAL=37, 
		INTEGER_VALUE=38, EXPONENT_VALUE=39, DECIMAL_VALUE=40, FLOAT_LITERAL=41, 
		DOUBLE_LITERAL=42, BIGDECIMAL_LITERAL=43, IDENTIFIER=44, BACKQUOTED_IDENTIFIER=45, 
		SIMPLE_COMMENT=46, BRACKETED_COMMENT=47, WS=48, UNRECOGNIZED=49;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"T__0", "T__1", "T__2", "T__3", "T__4", "T__5", "ALTER", "AS", "CALL", 
			"CREATE", "DAYS", "DELETE", "EXISTS", "HOURS", "IF", "MINUTES", "NOT", 
			"OF", "OR", "RENAME", "REPLACE", "RETAIN", "SHOW", "TABLE", "TAG", "TAGS", 
			"TO", "VERSION", "TRUE", "FALSE", "MAP", "PLUS", "MINUS", "STRING", "BIGINT_LITERAL", 
			"SMALLINT_LITERAL", "TINYINT_LITERAL", "INTEGER_VALUE", "EXPONENT_VALUE", 
			"DECIMAL_VALUE", "FLOAT_LITERAL", "DOUBLE_LITERAL", "BIGDECIMAL_LITERAL", 
			"IDENTIFIER", "BACKQUOTED_IDENTIFIER", "DECIMAL_DIGITS", "EXPONENT", 
			"DIGIT", "LETTER", "SIMPLE_COMMENT", "BRACKETED_COMMENT", "WS", "UNRECOGNIZED"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "';'", "'('", "','", "')'", "'=>'", "'.'", "'ALTER'", "'AS'", "'CALL'", 
			"'CREATE'", "'DAYS'", "'DELETE'", "'EXISTS'", "'HOURS'", "'IF'", "'MINUTES'", 
			"'NOT'", "'OF'", "'OR'", "'RENAME'", "'REPLACE'", "'RETAIN'", "'SHOW'", 
			"'TABLE'", "'TAG'", "'TAGS'", "'TO'", "'VERSION'", "'TRUE'", "'FALSE'", 
			"'MAP'", "'+'", "'-'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, "ALTER", "AS", "CALL", "CREATE", 
			"DAYS", "DELETE", "EXISTS", "HOURS", "IF", "MINUTES", "NOT", "OF", "OR", 
			"RENAME", "REPLACE", "RETAIN", "SHOW", "TABLE", "TAG", "TAGS", "TO", 
			"VERSION", "TRUE", "FALSE", "MAP", "PLUS", "MINUS", "STRING", "BIGINT_LITERAL", 
			"SMALLINT_LITERAL", "TINYINT_LITERAL", "INTEGER_VALUE", "EXPONENT_VALUE", 
			"DECIMAL_VALUE", "FLOAT_LITERAL", "DOUBLE_LITERAL", "BIGDECIMAL_LITERAL", 
			"IDENTIFIER", "BACKQUOTED_IDENTIFIER", "SIMPLE_COMMENT", "BRACKETED_COMMENT", 
			"WS", "UNRECOGNIZED"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	  /**
	   * Verify whether current token is a valid decimal token (which contains dot).
	   * Returns true if the character that follows the token is not a digit or letter or underscore.
	   *
	   * For example:
	   * For char stream "2.3", "2." is not a valid decimal token, because it is followed by digit '3'.
	   * For char stream "2.3_", "2.3" is not a valid decimal token, because it is followed by '_'.
	   * For char stream "2.3W", "2.3" is not a valid decimal token, because it is followed by 'W'.
	   * For char stream "12.0D 34.E2+0.12 "  12.0D is a valid decimal token because it is followed
	   * by a space. 34.E2 is a valid decimal token because it is followed by symbol '+'
	   * which is not a digit or letter or underscore.
	   */
	  public boolean isValidDecimal() {
	    int nextChar = _input.LA(1);
	    if (nextChar >= 'A' && nextChar <= 'Z' || nextChar >= '0' && nextChar <= '9' ||
	      nextChar == '_') {
	      return false;
	    } else {
	      return true;
	    }
	  }

	  /**
	   * This method will be called when we see '/*' and try to match it as a bracketed comment.
	   * If the next character is '+', it should be parsed as hint later, and we cannot match
	   * it as a bracketed comment.
	   *
	   * Returns true if the next character is '+'.
	   */
	  public boolean isHint() {
	    int nextChar = _input.LA(1);
	    if (nextChar == '+') {
	      return true;
	    } else {
	      return false;
	    }
	  }


	public PaimonSqlExtensionsLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "PaimonSqlExtensions.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	@Override
	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 38:
			return EXPONENT_VALUE_sempred((RuleContext)_localctx, predIndex);
		case 39:
			return DECIMAL_VALUE_sempred((RuleContext)_localctx, predIndex);
		case 40:
			return FLOAT_LITERAL_sempred((RuleContext)_localctx, predIndex);
		case 41:
			return DOUBLE_LITERAL_sempred((RuleContext)_localctx, predIndex);
		case 42:
			return BIGDECIMAL_LITERAL_sempred((RuleContext)_localctx, predIndex);
		case 50:
			return BRACKETED_COMMENT_sempred((RuleContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean EXPONENT_VALUE_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return isValidDecimal();
		}
		return true;
	}
	private boolean DECIMAL_VALUE_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return isValidDecimal();
		}
		return true;
	}
	private boolean FLOAT_LITERAL_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return isValidDecimal();
		}
		return true;
	}
	private boolean DOUBLE_LITERAL_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 3:
			return isValidDecimal();
		}
		return true;
	}
	private boolean BIGDECIMAL_LITERAL_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return isValidDecimal();
		}
		return true;
	}
	private boolean BRACKETED_COMMENT_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 5:
			return !isHint();
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2\63\u01e0\b\1\4\2"+
		"\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4"+
		"\13\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22"+
		"\t\22\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31"+
		"\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t"+
		" \4!\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t"+
		"+\4,\t,\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\4\64"+
		"\t\64\4\65\t\65\4\66\t\66\3\2\3\2\3\3\3\3\3\4\3\4\3\5\3\5\3\6\3\6\3\6"+
		"\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\13"+
		"\3\13\3\13\3\13\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r"+
		"\3\r\3\r\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\17\3\17\3\17\3\17\3\17\3"+
		"\17\3\20\3\20\3\20\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\22\3\22\3"+
		"\22\3\22\3\23\3\23\3\23\3\24\3\24\3\24\3\25\3\25\3\25\3\25\3\25\3\25\3"+
		"\25\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\27\3"+
		"\27\3\27\3\30\3\30\3\30\3\30\3\30\3\31\3\31\3\31\3\31\3\31\3\31\3\32\3"+
		"\32\3\32\3\32\3\33\3\33\3\33\3\33\3\33\3\34\3\34\3\34\3\35\3\35\3\35\3"+
		"\35\3\35\3\35\3\35\3\35\3\36\3\36\3\36\3\36\3\36\3\37\3\37\3\37\3\37\3"+
		"\37\3\37\3 \3 \3 \3 \3!\3!\3\"\3\"\3#\3#\3#\3#\7#\u010a\n#\f#\16#\u010d"+
		"\13#\3#\3#\3#\3#\3#\7#\u0114\n#\f#\16#\u0117\13#\3#\5#\u011a\n#\3$\6$"+
		"\u011d\n$\r$\16$\u011e\3$\3$\3%\6%\u0124\n%\r%\16%\u0125\3%\3%\3&\6&\u012b"+
		"\n&\r&\16&\u012c\3&\3&\3\'\6\'\u0132\n\'\r\'\16\'\u0133\3(\6(\u0137\n"+
		"(\r(\16(\u0138\3(\3(\3(\3(\3(\3(\5(\u0141\n(\3)\3)\3)\3*\6*\u0147\n*\r"+
		"*\16*\u0148\3*\5*\u014c\n*\3*\3*\3*\3*\5*\u0152\n*\3*\3*\3*\5*\u0157\n"+
		"*\3+\6+\u015a\n+\r+\16+\u015b\3+\5+\u015f\n+\3+\3+\3+\3+\5+\u0165\n+\3"+
		"+\3+\3+\5+\u016a\n+\3,\6,\u016d\n,\r,\16,\u016e\3,\5,\u0172\n,\3,\3,\3"+
		",\3,\3,\5,\u0179\n,\3,\3,\3,\3,\3,\5,\u0180\n,\3-\3-\3-\6-\u0185\n-\r"+
		"-\16-\u0186\3.\3.\3.\3.\7.\u018d\n.\f.\16.\u0190\13.\3.\3.\3/\6/\u0195"+
		"\n/\r/\16/\u0196\3/\3/\7/\u019b\n/\f/\16/\u019e\13/\3/\3/\6/\u01a2\n/"+
		"\r/\16/\u01a3\5/\u01a6\n/\3\60\3\60\5\60\u01aa\n\60\3\60\6\60\u01ad\n"+
		"\60\r\60\16\60\u01ae\3\61\3\61\3\62\3\62\3\63\3\63\3\63\3\63\3\63\3\63"+
		"\7\63\u01bb\n\63\f\63\16\63\u01be\13\63\3\63\5\63\u01c1\n\63\3\63\5\63"+
		"\u01c4\n\63\3\63\3\63\3\64\3\64\3\64\3\64\3\64\3\64\7\64\u01ce\n\64\f"+
		"\64\16\64\u01d1\13\64\3\64\3\64\3\64\3\64\3\64\3\65\6\65\u01d9\n\65\r"+
		"\65\16\65\u01da\3\65\3\65\3\66\3\66\3\u01cf\2\67\3\3\5\4\7\5\t\6\13\7"+
		"\r\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17\35\20\37\21!\22#\23%\24\'\25"+
		")\26+\27-\30/\31\61\32\63\33\65\34\67\359\36;\37= ?!A\"C#E$G%I&K\'M(O"+
		")Q*S+U,W-Y.[/]\2_\2a\2c\2e\60g\61i\62k\63\3\2\n\4\2))^^\4\2$$^^\3\2bb"+
		"\4\2--//\3\2\62;\3\2C\\\4\2\f\f\17\17\5\2\13\f\17\17\"\"\2\u0204\2\3\3"+
		"\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2"+
		"\17\3\2\2\2\2\21\3\2\2\2\2\23\3\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3"+
		"\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2!\3\2\2\2\2#\3\2\2\2\2"+
		"%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\2+\3\2\2\2\2-\3\2\2\2\2/\3\2\2\2\2\61"+
		"\3\2\2\2\2\63\3\2\2\2\2\65\3\2\2\2\2\67\3\2\2\2\29\3\2\2\2\2;\3\2\2\2"+
		"\2=\3\2\2\2\2?\3\2\2\2\2A\3\2\2\2\2C\3\2\2\2\2E\3\2\2\2\2G\3\2\2\2\2I"+
		"\3\2\2\2\2K\3\2\2\2\2M\3\2\2\2\2O\3\2\2\2\2Q\3\2\2\2\2S\3\2\2\2\2U\3\2"+
		"\2\2\2W\3\2\2\2\2Y\3\2\2\2\2[\3\2\2\2\2e\3\2\2\2\2g\3\2\2\2\2i\3\2\2\2"+
		"\2k\3\2\2\2\3m\3\2\2\2\5o\3\2\2\2\7q\3\2\2\2\ts\3\2\2\2\13u\3\2\2\2\r"+
		"x\3\2\2\2\17z\3\2\2\2\21\u0080\3\2\2\2\23\u0083\3\2\2\2\25\u0088\3\2\2"+
		"\2\27\u008f\3\2\2\2\31\u0094\3\2\2\2\33\u009b\3\2\2\2\35\u00a2\3\2\2\2"+
		"\37\u00a8\3\2\2\2!\u00ab\3\2\2\2#\u00b3\3\2\2\2%\u00b7\3\2\2\2\'\u00ba"+
		"\3\2\2\2)\u00bd\3\2\2\2+\u00c4\3\2\2\2-\u00cc\3\2\2\2/\u00d3\3\2\2\2\61"+
		"\u00d8\3\2\2\2\63\u00de\3\2\2\2\65\u00e2\3\2\2\2\67\u00e7\3\2\2\29\u00ea"+
		"\3\2\2\2;\u00f2\3\2\2\2=\u00f7\3\2\2\2?\u00fd\3\2\2\2A\u0101\3\2\2\2C"+
		"\u0103\3\2\2\2E\u0119\3\2\2\2G\u011c\3\2\2\2I\u0123\3\2\2\2K\u012a\3\2"+
		"\2\2M\u0131\3\2\2\2O\u0140\3\2\2\2Q\u0142\3\2\2\2S\u0156\3\2\2\2U\u0169"+
		"\3\2\2\2W\u017f\3\2\2\2Y\u0184\3\2\2\2[\u0188\3\2\2\2]\u01a5\3\2\2\2_"+
		"\u01a7\3\2\2\2a\u01b0\3\2\2\2c\u01b2\3\2\2\2e\u01b4\3\2\2\2g\u01c7\3\2"+
		"\2\2i\u01d8\3\2\2\2k\u01de\3\2\2\2mn\7=\2\2n\4\3\2\2\2op\7*\2\2p\6\3\2"+
		"\2\2qr\7.\2\2r\b\3\2\2\2st\7+\2\2t\n\3\2\2\2uv\7?\2\2vw\7@\2\2w\f\3\2"+
		"\2\2xy\7\60\2\2y\16\3\2\2\2z{\7C\2\2{|\7N\2\2|}\7V\2\2}~\7G\2\2~\177\7"+
		"T\2\2\177\20\3\2\2\2\u0080\u0081\7C\2\2\u0081\u0082\7U\2\2\u0082\22\3"+
		"\2\2\2\u0083\u0084\7E\2\2\u0084\u0085\7C\2\2\u0085\u0086\7N\2\2\u0086"+
		"\u0087\7N\2\2\u0087\24\3\2\2\2\u0088\u0089\7E\2\2\u0089\u008a\7T\2\2\u008a"+
		"\u008b\7G\2\2\u008b\u008c\7C\2\2\u008c\u008d\7V\2\2\u008d\u008e\7G\2\2"+
		"\u008e\26\3\2\2\2\u008f\u0090\7F\2\2\u0090\u0091\7C\2\2\u0091\u0092\7"+
		"[\2\2\u0092\u0093\7U\2\2\u0093\30\3\2\2\2\u0094\u0095\7F\2\2\u0095\u0096"+
		"\7G\2\2\u0096\u0097\7N\2\2\u0097\u0098\7G\2\2\u0098\u0099\7V\2\2\u0099"+
		"\u009a\7G\2\2\u009a\32\3\2\2\2\u009b\u009c\7G\2\2\u009c\u009d\7Z\2\2\u009d"+
		"\u009e\7K\2\2\u009e\u009f\7U\2\2\u009f\u00a0\7V\2\2\u00a0\u00a1\7U\2\2"+
		"\u00a1\34\3\2\2\2\u00a2\u00a3\7J\2\2\u00a3\u00a4\7Q\2\2\u00a4\u00a5\7"+
		"W\2\2\u00a5\u00a6\7T\2\2\u00a6\u00a7\7U\2\2\u00a7\36\3\2\2\2\u00a8\u00a9"+
		"\7K\2\2\u00a9\u00aa\7H\2\2\u00aa \3\2\2\2\u00ab\u00ac\7O\2\2\u00ac\u00ad"+
		"\7K\2\2\u00ad\u00ae\7P\2\2\u00ae\u00af\7W\2\2\u00af\u00b0\7V\2\2\u00b0"+
		"\u00b1\7G\2\2\u00b1\u00b2\7U\2\2\u00b2\"\3\2\2\2\u00b3\u00b4\7P\2\2\u00b4"+
		"\u00b5\7Q\2\2\u00b5\u00b6\7V\2\2\u00b6$\3\2\2\2\u00b7\u00b8\7Q\2\2\u00b8"+
		"\u00b9\7H\2\2\u00b9&\3\2\2\2\u00ba\u00bb\7Q\2\2\u00bb\u00bc\7T\2\2\u00bc"+
		"(\3\2\2\2\u00bd\u00be\7T\2\2\u00be\u00bf\7G\2\2\u00bf\u00c0\7P\2\2\u00c0"+
		"\u00c1\7C\2\2\u00c1\u00c2\7O\2\2\u00c2\u00c3\7G\2\2\u00c3*\3\2\2\2\u00c4"+
		"\u00c5\7T\2\2\u00c5\u00c6\7G\2\2\u00c6\u00c7\7R\2\2\u00c7\u00c8\7N\2\2"+
		"\u00c8\u00c9\7C\2\2\u00c9\u00ca\7E\2\2\u00ca\u00cb\7G\2\2\u00cb,\3\2\2"+
		"\2\u00cc\u00cd\7T\2\2\u00cd\u00ce\7G\2\2\u00ce\u00cf\7V\2\2\u00cf\u00d0"+
		"\7C\2\2\u00d0\u00d1\7K\2\2\u00d1\u00d2\7P\2\2\u00d2.\3\2\2\2\u00d3\u00d4"+
		"\7U\2\2\u00d4\u00d5\7J\2\2\u00d5\u00d6\7Q\2\2\u00d6\u00d7\7Y\2\2\u00d7"+
		"\60\3\2\2\2\u00d8\u00d9\7V\2\2\u00d9\u00da\7C\2\2\u00da\u00db\7D\2\2\u00db"+
		"\u00dc\7N\2\2\u00dc\u00dd\7G\2\2\u00dd\62\3\2\2\2\u00de\u00df\7V\2\2\u00df"+
		"\u00e0\7C\2\2\u00e0\u00e1\7I\2\2\u00e1\64\3\2\2\2\u00e2\u00e3\7V\2\2\u00e3"+
		"\u00e4\7C\2\2\u00e4\u00e5\7I\2\2\u00e5\u00e6\7U\2\2\u00e6\66\3\2\2\2\u00e7"+
		"\u00e8\7V\2\2\u00e8\u00e9\7Q\2\2\u00e98\3\2\2\2\u00ea\u00eb\7X\2\2\u00eb"+
		"\u00ec\7G\2\2\u00ec\u00ed\7T\2\2\u00ed\u00ee\7U\2\2\u00ee\u00ef\7K\2\2"+
		"\u00ef\u00f0\7Q\2\2\u00f0\u00f1\7P\2\2\u00f1:\3\2\2\2\u00f2\u00f3\7V\2"+
		"\2\u00f3\u00f4\7T\2\2\u00f4\u00f5\7W\2\2\u00f5\u00f6\7G\2\2\u00f6<\3\2"+
		"\2\2\u00f7\u00f8\7H\2\2\u00f8\u00f9\7C\2\2\u00f9\u00fa\7N\2\2\u00fa\u00fb"+
		"\7U\2\2\u00fb\u00fc\7G\2\2\u00fc>\3\2\2\2\u00fd\u00fe\7O\2\2\u00fe\u00ff"+
		"\7C\2\2\u00ff\u0100\7R\2\2\u0100@\3\2\2\2\u0101\u0102\7-\2\2\u0102B\3"+
		"\2\2\2\u0103\u0104\7/\2\2\u0104D\3\2\2\2\u0105\u010b\7)\2\2\u0106\u010a"+
		"\n\2\2\2\u0107\u0108\7^\2\2\u0108\u010a\13\2\2\2\u0109\u0106\3\2\2\2\u0109"+
		"\u0107\3\2\2\2\u010a\u010d\3\2\2\2\u010b\u0109\3\2\2\2\u010b\u010c\3\2"+
		"\2\2\u010c\u010e\3\2\2\2\u010d\u010b\3\2\2\2\u010e\u011a\7)\2\2\u010f"+
		"\u0115\7$\2\2\u0110\u0114\n\3\2\2\u0111\u0112\7^\2\2\u0112\u0114\13\2"+
		"\2\2\u0113\u0110\3\2\2\2\u0113\u0111\3\2\2\2\u0114\u0117\3\2\2\2\u0115"+
		"\u0113\3\2\2\2\u0115\u0116\3\2\2\2\u0116\u0118\3\2\2\2\u0117\u0115\3\2"+
		"\2\2\u0118\u011a\7$\2\2\u0119\u0105\3\2\2\2\u0119\u010f\3\2\2\2\u011a"+
		"F\3\2\2\2\u011b\u011d\5a\61\2\u011c\u011b\3\2\2\2\u011d\u011e\3\2\2\2"+
		"\u011e\u011c\3\2\2\2\u011e\u011f\3\2\2\2\u011f\u0120\3\2\2\2\u0120\u0121"+
		"\7N\2\2\u0121H\3\2\2\2\u0122\u0124\5a\61\2\u0123\u0122\3\2\2\2\u0124\u0125"+
		"\3\2\2\2\u0125\u0123\3\2\2\2\u0125\u0126\3\2\2\2\u0126\u0127\3\2\2\2\u0127"+
		"\u0128\7U\2\2\u0128J\3\2\2\2\u0129\u012b\5a\61\2\u012a\u0129\3\2\2\2\u012b"+
		"\u012c\3\2\2\2\u012c\u012a\3\2\2\2\u012c\u012d\3\2\2\2\u012d\u012e\3\2"+
		"\2\2\u012e\u012f\7[\2\2\u012fL\3\2\2\2\u0130\u0132\5a\61\2\u0131\u0130"+
		"\3\2\2\2\u0132\u0133\3\2\2\2\u0133\u0131\3\2\2\2\u0133\u0134\3\2\2\2\u0134"+
		"N\3\2\2\2\u0135\u0137\5a\61\2\u0136\u0135\3\2\2\2\u0137\u0138\3\2\2\2"+
		"\u0138\u0136\3\2\2\2\u0138\u0139\3\2\2\2\u0139\u013a\3\2\2\2\u013a\u013b"+
		"\5_\60\2\u013b\u0141\3\2\2\2\u013c\u013d\5]/\2\u013d\u013e\5_\60\2\u013e"+
		"\u013f\6(\2\2\u013f\u0141\3\2\2\2\u0140\u0136\3\2\2\2\u0140\u013c\3\2"+
		"\2\2\u0141P\3\2\2\2\u0142\u0143\5]/\2\u0143\u0144\6)\3\2\u0144R\3\2\2"+
		"\2\u0145\u0147\5a\61\2\u0146\u0145\3\2\2\2\u0147\u0148\3\2\2\2\u0148\u0146"+
		"\3\2\2\2\u0148\u0149\3\2\2\2\u0149\u014b\3\2\2\2\u014a\u014c\5_\60\2\u014b"+
		"\u014a\3\2\2\2\u014b\u014c\3\2\2\2\u014c\u014d\3\2\2\2\u014d\u014e\7H"+
		"\2\2\u014e\u0157\3\2\2\2\u014f\u0151\5]/\2\u0150\u0152\5_\60\2\u0151\u0150"+
		"\3\2\2\2\u0151\u0152\3\2\2\2\u0152\u0153\3\2\2\2\u0153\u0154\7H\2\2\u0154"+
		"\u0155\6*\4\2\u0155\u0157\3\2\2\2\u0156\u0146\3\2\2\2\u0156\u014f\3\2"+
		"\2\2\u0157T\3\2\2\2\u0158\u015a\5a\61\2\u0159\u0158\3\2\2\2\u015a\u015b"+
		"\3\2\2\2\u015b\u0159\3\2\2\2\u015b\u015c\3\2\2\2\u015c\u015e\3\2\2\2\u015d"+
		"\u015f\5_\60\2\u015e\u015d\3\2\2\2\u015e\u015f\3\2\2\2\u015f\u0160\3\2"+
		"\2\2\u0160\u0161\7F\2\2\u0161\u016a\3\2\2\2\u0162\u0164\5]/\2\u0163\u0165"+
		"\5_\60\2\u0164\u0163\3\2\2\2\u0164\u0165\3\2\2\2\u0165\u0166\3\2\2\2\u0166"+
		"\u0167\7F\2\2\u0167\u0168\6+\5\2\u0168\u016a\3\2\2\2\u0169\u0159\3\2\2"+
		"\2\u0169\u0162\3\2\2\2\u016aV\3\2\2\2\u016b\u016d\5a\61\2\u016c\u016b"+
		"\3\2\2\2\u016d\u016e\3\2\2\2\u016e\u016c\3\2\2\2\u016e\u016f\3\2\2\2\u016f"+
		"\u0171\3\2\2\2\u0170\u0172\5_\60\2\u0171\u0170\3\2\2\2\u0171\u0172\3\2"+
		"\2\2\u0172\u0173\3\2\2\2\u0173\u0174\7D\2\2\u0174\u0175\7F\2\2\u0175\u0180"+
		"\3\2\2\2\u0176\u0178\5]/\2\u0177\u0179\5_\60\2\u0178\u0177\3\2\2\2\u0178"+
		"\u0179\3\2\2\2\u0179\u017a\3\2\2\2\u017a\u017b\7D\2\2\u017b\u017c\7F\2"+
		"\2\u017c\u017d\3\2\2\2\u017d\u017e\6,\6\2\u017e\u0180\3\2\2\2\u017f\u016c"+
		"\3\2\2\2\u017f\u0176\3\2\2\2\u0180X\3\2\2\2\u0181\u0185\5c\62\2\u0182"+
		"\u0185\5a\61\2\u0183\u0185\7a\2\2\u0184\u0181\3\2\2\2\u0184\u0182\3\2"+
		"\2\2\u0184\u0183\3\2\2\2\u0185\u0186\3\2\2\2\u0186\u0184\3\2\2\2\u0186"+
		"\u0187\3\2\2\2\u0187Z\3\2\2\2\u0188\u018e\7b\2\2\u0189\u018d\n\4\2\2\u018a"+
		"\u018b\7b\2\2\u018b\u018d\7b\2\2\u018c\u0189\3\2\2\2\u018c\u018a\3\2\2"+
		"\2\u018d\u0190\3\2\2\2\u018e\u018c\3\2\2\2\u018e\u018f\3\2\2\2\u018f\u0191"+
		"\3\2\2\2\u0190\u018e\3\2\2\2\u0191\u0192\7b\2\2\u0192\\\3\2\2\2\u0193"+
		"\u0195\5a\61\2\u0194\u0193\3\2\2\2\u0195\u0196\3\2\2\2\u0196\u0194\3\2"+
		"\2\2\u0196\u0197\3\2\2\2\u0197\u0198\3\2\2\2\u0198\u019c\7\60\2\2\u0199"+
		"\u019b\5a\61\2\u019a\u0199\3\2\2\2\u019b\u019e\3\2\2\2\u019c\u019a\3\2"+
		"\2\2\u019c\u019d\3\2\2\2\u019d\u01a6\3\2\2\2\u019e\u019c\3\2\2\2\u019f"+
		"\u01a1\7\60\2\2\u01a0\u01a2\5a\61\2\u01a1\u01a0\3\2\2\2\u01a2\u01a3\3"+
		"\2\2\2\u01a3\u01a1\3\2\2\2\u01a3\u01a4\3\2\2\2\u01a4\u01a6\3\2\2\2\u01a5"+
		"\u0194\3\2\2\2\u01a5\u019f\3\2\2\2\u01a6^\3\2\2\2\u01a7\u01a9\7G\2\2\u01a8"+
		"\u01aa\t\5\2\2\u01a9\u01a8\3\2\2\2\u01a9\u01aa\3\2\2\2\u01aa\u01ac\3\2"+
		"\2\2\u01ab\u01ad\5a\61\2\u01ac\u01ab\3\2\2\2\u01ad\u01ae\3\2\2\2\u01ae"+
		"\u01ac\3\2\2\2\u01ae\u01af\3\2\2\2\u01af`\3\2\2\2\u01b0\u01b1\t\6\2\2"+
		"\u01b1b\3\2\2\2\u01b2\u01b3\t\7\2\2\u01b3d\3\2\2\2\u01b4\u01b5\7/\2\2"+
		"\u01b5\u01b6\7/\2\2\u01b6\u01bc\3\2\2\2\u01b7\u01b8\7^\2\2\u01b8\u01bb"+
		"\7\f\2\2\u01b9\u01bb\n\b\2\2\u01ba\u01b7\3\2\2\2\u01ba\u01b9\3\2\2\2\u01bb"+
		"\u01be\3\2\2\2\u01bc\u01ba\3\2\2\2\u01bc\u01bd\3\2\2\2\u01bd\u01c0\3\2"+
		"\2\2\u01be\u01bc\3\2\2\2\u01bf\u01c1\7\17\2\2\u01c0\u01bf\3\2\2\2\u01c0"+
		"\u01c1\3\2\2\2\u01c1\u01c3\3\2\2\2\u01c2\u01c4\7\f\2\2\u01c3\u01c2\3\2"+
		"\2\2\u01c3\u01c4\3\2\2\2\u01c4\u01c5\3\2\2\2\u01c5\u01c6\b\63\2\2\u01c6"+
		"f\3\2\2\2\u01c7\u01c8\7\61\2\2\u01c8\u01c9\7,\2\2\u01c9\u01ca\3\2\2\2"+
		"\u01ca\u01cf\6\64\7\2\u01cb\u01ce\5g\64\2\u01cc\u01ce\13\2\2\2\u01cd\u01cb"+
		"\3\2\2\2\u01cd\u01cc\3\2\2\2\u01ce\u01d1\3\2\2\2\u01cf\u01d0\3\2\2\2\u01cf"+
		"\u01cd\3\2\2\2\u01d0\u01d2\3\2\2\2\u01d1\u01cf\3\2\2\2\u01d2\u01d3\7,"+
		"\2\2\u01d3\u01d4\7\61\2\2\u01d4\u01d5\3\2\2\2\u01d5\u01d6\b\64\2\2\u01d6"+
		"h\3\2\2\2\u01d7\u01d9\t\t\2\2\u01d8\u01d7\3\2\2\2\u01d9\u01da\3\2\2\2"+
		"\u01da\u01d8\3\2\2\2\u01da\u01db\3\2\2\2\u01db\u01dc\3\2\2\2\u01dc\u01dd"+
		"\b\65\2\2\u01ddj\3\2\2\2\u01de\u01df\13\2\2\2\u01dfl\3\2\2\2+\2\u0109"+
		"\u010b\u0113\u0115\u0119\u011e\u0125\u012c\u0133\u0138\u0140\u0148\u014b"+
		"\u0151\u0156\u015b\u015e\u0164\u0169\u016e\u0171\u0178\u017f\u0184\u0186"+
		"\u018c\u018e\u0196\u019c\u01a3\u01a5\u01a9\u01ae\u01ba\u01bc\u01c0\u01c3"+
		"\u01cd\u01cf\u01da\3\2\3\2";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}