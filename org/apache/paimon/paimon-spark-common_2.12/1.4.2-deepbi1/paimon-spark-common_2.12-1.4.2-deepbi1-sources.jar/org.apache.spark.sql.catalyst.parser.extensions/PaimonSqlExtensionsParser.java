// Generated from org.apache.spark.sql.catalyst.parser.extensions/PaimonSqlExtensions.g4 by ANTLR 4.9.3
package org.apache.spark.sql.catalyst.parser.extensions;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PaimonSqlExtensionsParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.3", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, ALTER=7, AS=8, CALL=9, 
		CREATE=10, DAYS=11, DELETE=12, EXISTS=13, HOURS=14, IF=15, MINUTES=16, 
		NOT=17, OF=18, OR=19, RENAME=20, REPLACE=21, RETAIN=22, SHOW=23, TABLE=24, 
		TAG=25, TAGS=26, TO=27, VERSION=28, TRUE=29, FALSE=30, MAP=31, PLUS=32, 
		MINUS=33, STRING=34, BIGINT_LITERAL=35, SMALLINT_LITERAL=36, TINYINT_LITERAL=37, 
		INTEGER_VALUE=38, EXPONENT_VALUE=39, DECIMAL_VALUE=40, FLOAT_LITERAL=41, 
		DOUBLE_LITERAL=42, BIGDECIMAL_LITERAL=43, IDENTIFIER=44, BACKQUOTED_IDENTIFIER=45, 
		SIMPLE_COMMENT=46, BRACKETED_COMMENT=47, WS=48, UNRECOGNIZED=49;
	public static final int
		RULE_singleStatement = 0, RULE_statement = 1, RULE_callArgument = 2, RULE_createReplaceTagClause = 3, 
		RULE_tagOptions = 4, RULE_snapshotId = 5, RULE_timeRetain = 6, RULE_timeUnit = 7, 
		RULE_expression = 8, RULE_constant = 9, RULE_stringMap = 10, RULE_booleanValue = 11, 
		RULE_number = 12, RULE_multipartIdentifier = 13, RULE_identifier = 14, 
		RULE_quotedIdentifier = 15, RULE_nonReserved = 16;
	private static String[] makeRuleNames() {
		return new String[] {
			"singleStatement", "statement", "callArgument", "createReplaceTagClause", 
			"tagOptions", "snapshotId", "timeRetain", "timeUnit", "expression", "constant", 
			"stringMap", "booleanValue", "number", "multipartIdentifier", "identifier", 
			"quotedIdentifier", "nonReserved"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "';'", "'('", "','", "')'", "'=>'", "'.'", "'ALTER'", "'AS'", "'CALL'", 
			"'CREATE'", "'DAYS'", "'DELETE'", "'EXISTS'", "'HOURS'", "'IF'", "'MINUTES'", 
			"'NOT'", "'OF'", "'OR'", "'RENAME'", "'REPLACE'", "'RETAIN'", "'SHOW'", 
			"'TABLE'", "'TAG'", "'TAGS'", "'TO'", "'VERSION'", "'TRUE'", "'FALSE'", 
			"'MAP'", "'+'", "'-'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, "ALTER", "AS", "CALL", "CREATE", 
			"DAYS", "DELETE", "EXISTS", "HOURS", "IF", "MINUTES", "NOT", "OF", "OR", 
			"RENAME", "REPLACE", "RETAIN", "SHOW", "TABLE", "TAG", "TAGS", "TO", 
			"VERSION", "TRUE", "FALSE", "MAP", "PLUS", "MINUS", "STRING", "BIGINT_LITERAL", 
			"SMALLINT_LITERAL", "TINYINT_LITERAL", "INTEGER_VALUE", "EXPONENT_VALUE", 
			"DECIMAL_VALUE", "FLOAT_LITERAL", "DOUBLE_LITERAL", "BIGDECIMAL_LITERAL", 
			"IDENTIFIER", "BACKQUOTED_IDENTIFIER", "SIMPLE_COMMENT", "BRACKETED_COMMENT", 
			"WS", "UNRECOGNIZED"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "PaimonSqlExtensions.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public PaimonSqlExtensionsParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class SingleStatementContext extends ParserRuleContext {
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public TerminalNode EOF() { return getToken(PaimonSqlExtensionsParser.EOF, 0); }
		public SingleStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_singleStatement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterSingleStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitSingleStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitSingleStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SingleStatementContext singleStatement() throws RecognitionException {
		SingleStatementContext _localctx = new SingleStatementContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_singleStatement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(34);
			statement();
			setState(38);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(35);
				match(T__0);
				}
				}
				setState(40);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(41);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
	 
		public StatementContext() { }
		public void copyFrom(StatementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class CallContext extends StatementContext {
		public TerminalNode CALL() { return getToken(PaimonSqlExtensionsParser.CALL, 0); }
		public MultipartIdentifierContext multipartIdentifier() {
			return getRuleContext(MultipartIdentifierContext.class,0);
		}
		public List<CallArgumentContext> callArgument() {
			return getRuleContexts(CallArgumentContext.class);
		}
		public CallArgumentContext callArgument(int i) {
			return getRuleContext(CallArgumentContext.class,i);
		}
		public CallContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterCall(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitCall(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitCall(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DeleteTagContext extends StatementContext {
		public TerminalNode ALTER() { return getToken(PaimonSqlExtensionsParser.ALTER, 0); }
		public TerminalNode TABLE() { return getToken(PaimonSqlExtensionsParser.TABLE, 0); }
		public MultipartIdentifierContext multipartIdentifier() {
			return getRuleContext(MultipartIdentifierContext.class,0);
		}
		public TerminalNode DELETE() { return getToken(PaimonSqlExtensionsParser.DELETE, 0); }
		public TerminalNode TAG() { return getToken(PaimonSqlExtensionsParser.TAG, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode IF() { return getToken(PaimonSqlExtensionsParser.IF, 0); }
		public TerminalNode EXISTS() { return getToken(PaimonSqlExtensionsParser.EXISTS, 0); }
		public DeleteTagContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterDeleteTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitDeleteTag(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitDeleteTag(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CreateOrReplaceTagContext extends StatementContext {
		public TerminalNode ALTER() { return getToken(PaimonSqlExtensionsParser.ALTER, 0); }
		public TerminalNode TABLE() { return getToken(PaimonSqlExtensionsParser.TABLE, 0); }
		public MultipartIdentifierContext multipartIdentifier() {
			return getRuleContext(MultipartIdentifierContext.class,0);
		}
		public CreateReplaceTagClauseContext createReplaceTagClause() {
			return getRuleContext(CreateReplaceTagClauseContext.class,0);
		}
		public CreateOrReplaceTagContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterCreateOrReplaceTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitCreateOrReplaceTag(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitCreateOrReplaceTag(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ShowTagsContext extends StatementContext {
		public TerminalNode SHOW() { return getToken(PaimonSqlExtensionsParser.SHOW, 0); }
		public TerminalNode TAGS() { return getToken(PaimonSqlExtensionsParser.TAGS, 0); }
		public MultipartIdentifierContext multipartIdentifier() {
			return getRuleContext(MultipartIdentifierContext.class,0);
		}
		public ShowTagsContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterShowTags(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitShowTags(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitShowTags(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RenameTagContext extends StatementContext {
		public TerminalNode ALTER() { return getToken(PaimonSqlExtensionsParser.ALTER, 0); }
		public TerminalNode TABLE() { return getToken(PaimonSqlExtensionsParser.TABLE, 0); }
		public MultipartIdentifierContext multipartIdentifier() {
			return getRuleContext(MultipartIdentifierContext.class,0);
		}
		public TerminalNode RENAME() { return getToken(PaimonSqlExtensionsParser.RENAME, 0); }
		public TerminalNode TAG() { return getToken(PaimonSqlExtensionsParser.TAG, 0); }
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public TerminalNode TO() { return getToken(PaimonSqlExtensionsParser.TO, 0); }
		public RenameTagContext(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterRenameTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitRenameTag(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitRenameTag(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_statement);
		int _la;
		try {
			setState(86);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				_localctx = new CallContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(43);
				match(CALL);
				setState(44);
				multipartIdentifier();
				setState(45);
				match(T__1);
				setState(54);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ALTER) | (1L << AS) | (1L << CALL) | (1L << CREATE) | (1L << DAYS) | (1L << DELETE) | (1L << EXISTS) | (1L << HOURS) | (1L << IF) | (1L << NOT) | (1L << OF) | (1L << OR) | (1L << REPLACE) | (1L << RETAIN) | (1L << TABLE) | (1L << TAG) | (1L << VERSION) | (1L << TRUE) | (1L << FALSE) | (1L << MAP) | (1L << MINUS) | (1L << STRING) | (1L << BIGINT_LITERAL) | (1L << SMALLINT_LITERAL) | (1L << TINYINT_LITERAL) | (1L << INTEGER_VALUE) | (1L << EXPONENT_VALUE) | (1L << DECIMAL_VALUE) | (1L << FLOAT_LITERAL) | (1L << DOUBLE_LITERAL) | (1L << BIGDECIMAL_LITERAL) | (1L << IDENTIFIER) | (1L << BACKQUOTED_IDENTIFIER))) != 0)) {
					{
					setState(46);
					callArgument();
					setState(51);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==T__2) {
						{
						{
						setState(47);
						match(T__2);
						setState(48);
						callArgument();
						}
						}
						setState(53);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(56);
				match(T__3);
				}
				break;
			case 2:
				_localctx = new ShowTagsContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(58);
				match(SHOW);
				setState(59);
				match(TAGS);
				setState(60);
				multipartIdentifier();
				}
				break;
			case 3:
				_localctx = new CreateOrReplaceTagContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(61);
				match(ALTER);
				setState(62);
				match(TABLE);
				setState(63);
				multipartIdentifier();
				setState(64);
				createReplaceTagClause();
				}
				break;
			case 4:
				_localctx = new DeleteTagContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(66);
				match(ALTER);
				setState(67);
				match(TABLE);
				setState(68);
				multipartIdentifier();
				setState(69);
				match(DELETE);
				setState(70);
				match(TAG);
				setState(73);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
				case 1:
					{
					setState(71);
					match(IF);
					setState(72);
					match(EXISTS);
					}
					break;
				}
				setState(75);
				identifier();
				}
				break;
			case 5:
				_localctx = new RenameTagContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(77);
				match(ALTER);
				setState(78);
				match(TABLE);
				setState(79);
				multipartIdentifier();
				setState(80);
				match(RENAME);
				setState(81);
				match(TAG);
				setState(82);
				identifier();
				setState(83);
				match(TO);
				setState(84);
				identifier();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CallArgumentContext extends ParserRuleContext {
		public CallArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_callArgument; }
	 
		public CallArgumentContext() { }
		public void copyFrom(CallArgumentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PositionalArgumentContext extends CallArgumentContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositionalArgumentContext(CallArgumentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterPositionalArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitPositionalArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitPositionalArgument(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NamedArgumentContext extends CallArgumentContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public NamedArgumentContext(CallArgumentContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterNamedArgument(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitNamedArgument(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitNamedArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CallArgumentContext callArgument() throws RecognitionException {
		CallArgumentContext _localctx = new CallArgumentContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_callArgument);
		try {
			setState(93);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				_localctx = new PositionalArgumentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(88);
				expression();
				}
				break;
			case 2:
				_localctx = new NamedArgumentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(89);
				identifier();
				setState(90);
				match(T__4);
				setState(91);
				expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CreateReplaceTagClauseContext extends ParserRuleContext {
		public TerminalNode CREATE() { return getToken(PaimonSqlExtensionsParser.CREATE, 0); }
		public TerminalNode TAG() { return getToken(PaimonSqlExtensionsParser.TAG, 0); }
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TagOptionsContext tagOptions() {
			return getRuleContext(TagOptionsContext.class,0);
		}
		public TerminalNode IF() { return getToken(PaimonSqlExtensionsParser.IF, 0); }
		public TerminalNode NOT() { return getToken(PaimonSqlExtensionsParser.NOT, 0); }
		public TerminalNode EXISTS() { return getToken(PaimonSqlExtensionsParser.EXISTS, 0); }
		public TerminalNode REPLACE() { return getToken(PaimonSqlExtensionsParser.REPLACE, 0); }
		public TerminalNode OR() { return getToken(PaimonSqlExtensionsParser.OR, 0); }
		public CreateReplaceTagClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_createReplaceTagClause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterCreateReplaceTagClause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitCreateReplaceTagClause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitCreateReplaceTagClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CreateReplaceTagClauseContext createReplaceTagClause() throws RecognitionException {
		CreateReplaceTagClauseContext _localctx = new CreateReplaceTagClauseContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_createReplaceTagClause);
		int _la;
		try {
			setState(114);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(95);
				match(CREATE);
				setState(96);
				match(TAG);
				setState(100);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
				case 1:
					{
					setState(97);
					match(IF);
					setState(98);
					match(NOT);
					setState(99);
					match(EXISTS);
					}
					break;
				}
				setState(102);
				identifier();
				setState(103);
				tagOptions();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(107);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==CREATE) {
					{
					setState(105);
					match(CREATE);
					setState(106);
					match(OR);
					}
				}

				setState(109);
				match(REPLACE);
				setState(110);
				match(TAG);
				setState(111);
				identifier();
				setState(112);
				tagOptions();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TagOptionsContext extends ParserRuleContext {
		public TerminalNode AS() { return getToken(PaimonSqlExtensionsParser.AS, 0); }
		public TerminalNode OF() { return getToken(PaimonSqlExtensionsParser.OF, 0); }
		public TerminalNode VERSION() { return getToken(PaimonSqlExtensionsParser.VERSION, 0); }
		public SnapshotIdContext snapshotId() {
			return getRuleContext(SnapshotIdContext.class,0);
		}
		public TimeRetainContext timeRetain() {
			return getRuleContext(TimeRetainContext.class,0);
		}
		public TagOptionsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tagOptions; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterTagOptions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitTagOptions(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitTagOptions(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TagOptionsContext tagOptions() throws RecognitionException {
		TagOptionsContext _localctx = new TagOptionsContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_tagOptions);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(120);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(116);
				match(AS);
				setState(117);
				match(OF);
				setState(118);
				match(VERSION);
				setState(119);
				snapshotId();
				}
			}

			setState(123);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==RETAIN) {
				{
				setState(122);
				timeRetain();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SnapshotIdContext extends ParserRuleContext {
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public SnapshotIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_snapshotId; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterSnapshotId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitSnapshotId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitSnapshotId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SnapshotIdContext snapshotId() throws RecognitionException {
		SnapshotIdContext _localctx = new SnapshotIdContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_snapshotId);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(125);
			number();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TimeRetainContext extends ParserRuleContext {
		public TerminalNode RETAIN() { return getToken(PaimonSqlExtensionsParser.RETAIN, 0); }
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public TimeUnitContext timeUnit() {
			return getRuleContext(TimeUnitContext.class,0);
		}
		public TimeRetainContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeRetain; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterTimeRetain(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitTimeRetain(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitTimeRetain(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeRetainContext timeRetain() throws RecognitionException {
		TimeRetainContext _localctx = new TimeRetainContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_timeRetain);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(127);
			match(RETAIN);
			setState(128);
			number();
			setState(129);
			timeUnit();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TimeUnitContext extends ParserRuleContext {
		public TerminalNode DAYS() { return getToken(PaimonSqlExtensionsParser.DAYS, 0); }
		public TerminalNode HOURS() { return getToken(PaimonSqlExtensionsParser.HOURS, 0); }
		public TerminalNode MINUTES() { return getToken(PaimonSqlExtensionsParser.MINUTES, 0); }
		public TimeUnitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_timeUnit; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterTimeUnit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitTimeUnit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitTimeUnit(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TimeUnitContext timeUnit() throws RecognitionException {
		TimeUnitContext _localctx = new TimeUnitContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_timeUnit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << DAYS) | (1L << HOURS) | (1L << MINUTES))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public StringMapContext stringMap() {
			return getRuleContext(StringMapContext.class,0);
		}
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_expression);
		try {
			setState(135);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(133);
				constant();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(134);
				stringMap();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConstantContext extends ParserRuleContext {
		public ConstantContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constant; }
	 
		public ConstantContext() { }
		public void copyFrom(ConstantContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class StringLiteralContext extends ConstantContext {
		public List<TerminalNode> STRING() { return getTokens(PaimonSqlExtensionsParser.STRING); }
		public TerminalNode STRING(int i) {
			return getToken(PaimonSqlExtensionsParser.STRING, i);
		}
		public StringLiteralContext(ConstantContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterStringLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitStringLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitStringLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TypeConstructorContext extends ConstantContext {
		public IdentifierContext identifier() {
			return getRuleContext(IdentifierContext.class,0);
		}
		public TerminalNode STRING() { return getToken(PaimonSqlExtensionsParser.STRING, 0); }
		public TypeConstructorContext(ConstantContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterTypeConstructor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitTypeConstructor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitTypeConstructor(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NumericLiteralContext extends ConstantContext {
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public NumericLiteralContext(ConstantContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterNumericLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitNumericLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitNumericLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BooleanLiteralContext extends ConstantContext {
		public BooleanValueContext booleanValue() {
			return getRuleContext(BooleanValueContext.class,0);
		}
		public BooleanLiteralContext(ConstantContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterBooleanLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitBooleanLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitBooleanLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstantContext constant() throws RecognitionException {
		ConstantContext _localctx = new ConstantContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_constant);
		int _la;
		try {
			setState(147);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				_localctx = new NumericLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(137);
				number();
				}
				break;
			case 2:
				_localctx = new BooleanLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(138);
				booleanValue();
				}
				break;
			case 3:
				_localctx = new StringLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(140); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(139);
					match(STRING);
					}
					}
					setState(142); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==STRING );
				}
				break;
			case 4:
				_localctx = new TypeConstructorContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(144);
				identifier();
				setState(145);
				match(STRING);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringMapContext extends ParserRuleContext {
		public TerminalNode MAP() { return getToken(PaimonSqlExtensionsParser.MAP, 0); }
		public List<ConstantContext> constant() {
			return getRuleContexts(ConstantContext.class);
		}
		public ConstantContext constant(int i) {
			return getRuleContext(ConstantContext.class,i);
		}
		public StringMapContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stringMap; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterStringMap(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitStringMap(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitStringMap(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringMapContext stringMap() throws RecognitionException {
		StringMapContext _localctx = new StringMapContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_stringMap);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(149);
			match(MAP);
			setState(150);
			match(T__1);
			setState(151);
			constant();
			setState(156);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__2) {
				{
				{
				setState(152);
				match(T__2);
				setState(153);
				constant();
				}
				}
				setState(158);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(159);
			match(T__3);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BooleanValueContext extends ParserRuleContext {
		public TerminalNode TRUE() { return getToken(PaimonSqlExtensionsParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(PaimonSqlExtensionsParser.FALSE, 0); }
		public BooleanValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_booleanValue; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterBooleanValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitBooleanValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitBooleanValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BooleanValueContext booleanValue() throws RecognitionException {
		BooleanValueContext _localctx = new BooleanValueContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_booleanValue);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(161);
			_la = _input.LA(1);
			if ( !(_la==TRUE || _la==FALSE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NumberContext extends ParserRuleContext {
		public NumberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_number; }
	 
		public NumberContext() { }
		public void copyFrom(NumberContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class DecimalLiteralContext extends NumberContext {
		public TerminalNode DECIMAL_VALUE() { return getToken(PaimonSqlExtensionsParser.DECIMAL_VALUE, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public DecimalLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterDecimalLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitDecimalLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitDecimalLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BigIntLiteralContext extends NumberContext {
		public TerminalNode BIGINT_LITERAL() { return getToken(PaimonSqlExtensionsParser.BIGINT_LITERAL, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public BigIntLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterBigIntLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitBigIntLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitBigIntLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TinyIntLiteralContext extends NumberContext {
		public TerminalNode TINYINT_LITERAL() { return getToken(PaimonSqlExtensionsParser.TINYINT_LITERAL, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public TinyIntLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterTinyIntLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitTinyIntLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitTinyIntLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BigDecimalLiteralContext extends NumberContext {
		public TerminalNode BIGDECIMAL_LITERAL() { return getToken(PaimonSqlExtensionsParser.BIGDECIMAL_LITERAL, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public BigDecimalLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterBigDecimalLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitBigDecimalLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitBigDecimalLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExponentLiteralContext extends NumberContext {
		public TerminalNode EXPONENT_VALUE() { return getToken(PaimonSqlExtensionsParser.EXPONENT_VALUE, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public ExponentLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterExponentLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitExponentLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitExponentLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DoubleLiteralContext extends NumberContext {
		public TerminalNode DOUBLE_LITERAL() { return getToken(PaimonSqlExtensionsParser.DOUBLE_LITERAL, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public DoubleLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterDoubleLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitDoubleLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitDoubleLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IntegerLiteralContext extends NumberContext {
		public TerminalNode INTEGER_VALUE() { return getToken(PaimonSqlExtensionsParser.INTEGER_VALUE, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public IntegerLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterIntegerLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitIntegerLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitIntegerLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FloatLiteralContext extends NumberContext {
		public TerminalNode FLOAT_LITERAL() { return getToken(PaimonSqlExtensionsParser.FLOAT_LITERAL, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public FloatLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterFloatLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitFloatLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitFloatLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class SmallIntLiteralContext extends NumberContext {
		public TerminalNode SMALLINT_LITERAL() { return getToken(PaimonSqlExtensionsParser.SMALLINT_LITERAL, 0); }
		public TerminalNode MINUS() { return getToken(PaimonSqlExtensionsParser.MINUS, 0); }
		public SmallIntLiteralContext(NumberContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterSmallIntLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitSmallIntLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitSmallIntLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumberContext number() throws RecognitionException {
		NumberContext _localctx = new NumberContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_number);
		int _la;
		try {
			setState(199);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
			case 1:
				_localctx = new ExponentLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(164);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(163);
					match(MINUS);
					}
				}

				setState(166);
				match(EXPONENT_VALUE);
				}
				break;
			case 2:
				_localctx = new DecimalLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(168);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(167);
					match(MINUS);
					}
				}

				setState(170);
				match(DECIMAL_VALUE);
				}
				break;
			case 3:
				_localctx = new IntegerLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(172);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(171);
					match(MINUS);
					}
				}

				setState(174);
				match(INTEGER_VALUE);
				}
				break;
			case 4:
				_localctx = new BigIntLiteralContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(176);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(175);
					match(MINUS);
					}
				}

				setState(178);
				match(BIGINT_LITERAL);
				}
				break;
			case 5:
				_localctx = new SmallIntLiteralContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(180);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(179);
					match(MINUS);
					}
				}

				setState(182);
				match(SMALLINT_LITERAL);
				}
				break;
			case 6:
				_localctx = new TinyIntLiteralContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(184);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(183);
					match(MINUS);
					}
				}

				setState(186);
				match(TINYINT_LITERAL);
				}
				break;
			case 7:
				_localctx = new DoubleLiteralContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(188);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(187);
					match(MINUS);
					}
				}

				setState(190);
				match(DOUBLE_LITERAL);
				}
				break;
			case 8:
				_localctx = new FloatLiteralContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(192);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(191);
					match(MINUS);
					}
				}

				setState(194);
				match(FLOAT_LITERAL);
				}
				break;
			case 9:
				_localctx = new BigDecimalLiteralContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(196);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==MINUS) {
					{
					setState(195);
					match(MINUS);
					}
				}

				setState(198);
				match(BIGDECIMAL_LITERAL);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MultipartIdentifierContext extends ParserRuleContext {
		public IdentifierContext identifier;
		public List<IdentifierContext> parts = new ArrayList<IdentifierContext>();
		public List<IdentifierContext> identifier() {
			return getRuleContexts(IdentifierContext.class);
		}
		public IdentifierContext identifier(int i) {
			return getRuleContext(IdentifierContext.class,i);
		}
		public MultipartIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multipartIdentifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterMultipartIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitMultipartIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitMultipartIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MultipartIdentifierContext multipartIdentifier() throws RecognitionException {
		MultipartIdentifierContext _localctx = new MultipartIdentifierContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_multipartIdentifier);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(201);
			((MultipartIdentifierContext)_localctx).identifier = identifier();
			((MultipartIdentifierContext)_localctx).parts.add(((MultipartIdentifierContext)_localctx).identifier);
			setState(206);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__5) {
				{
				{
				setState(202);
				match(T__5);
				setState(203);
				((MultipartIdentifierContext)_localctx).identifier = identifier();
				((MultipartIdentifierContext)_localctx).parts.add(((MultipartIdentifierContext)_localctx).identifier);
				}
				}
				setState(208);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdentifierContext extends ParserRuleContext {
		public IdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identifier; }
	 
		public IdentifierContext() { }
		public void copyFrom(IdentifierContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class QuotedIdentifierAlternativeContext extends IdentifierContext {
		public QuotedIdentifierContext quotedIdentifier() {
			return getRuleContext(QuotedIdentifierContext.class,0);
		}
		public QuotedIdentifierAlternativeContext(IdentifierContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterQuotedIdentifierAlternative(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitQuotedIdentifierAlternative(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitQuotedIdentifierAlternative(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnquotedIdentifierContext extends IdentifierContext {
		public TerminalNode IDENTIFIER() { return getToken(PaimonSqlExtensionsParser.IDENTIFIER, 0); }
		public NonReservedContext nonReserved() {
			return getRuleContext(NonReservedContext.class,0);
		}
		public UnquotedIdentifierContext(IdentifierContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterUnquotedIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitUnquotedIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitUnquotedIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentifierContext identifier() throws RecognitionException {
		IdentifierContext _localctx = new IdentifierContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_identifier);
		try {
			setState(212);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				_localctx = new UnquotedIdentifierContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(209);
				match(IDENTIFIER);
				}
				break;
			case BACKQUOTED_IDENTIFIER:
				_localctx = new QuotedIdentifierAlternativeContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(210);
				quotedIdentifier();
				}
				break;
			case ALTER:
			case AS:
			case CALL:
			case CREATE:
			case DAYS:
			case DELETE:
			case EXISTS:
			case HOURS:
			case IF:
			case NOT:
			case OF:
			case OR:
			case REPLACE:
			case RETAIN:
			case TABLE:
			case TAG:
			case VERSION:
			case TRUE:
			case FALSE:
			case MAP:
				_localctx = new UnquotedIdentifierContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(211);
				nonReserved();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QuotedIdentifierContext extends ParserRuleContext {
		public TerminalNode BACKQUOTED_IDENTIFIER() { return getToken(PaimonSqlExtensionsParser.BACKQUOTED_IDENTIFIER, 0); }
		public QuotedIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_quotedIdentifier; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterQuotedIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitQuotedIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitQuotedIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QuotedIdentifierContext quotedIdentifier() throws RecognitionException {
		QuotedIdentifierContext _localctx = new QuotedIdentifierContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_quotedIdentifier);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(214);
			match(BACKQUOTED_IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NonReservedContext extends ParserRuleContext {
		public TerminalNode ALTER() { return getToken(PaimonSqlExtensionsParser.ALTER, 0); }
		public TerminalNode AS() { return getToken(PaimonSqlExtensionsParser.AS, 0); }
		public TerminalNode CALL() { return getToken(PaimonSqlExtensionsParser.CALL, 0); }
		public TerminalNode CREATE() { return getToken(PaimonSqlExtensionsParser.CREATE, 0); }
		public TerminalNode DAYS() { return getToken(PaimonSqlExtensionsParser.DAYS, 0); }
		public TerminalNode DELETE() { return getToken(PaimonSqlExtensionsParser.DELETE, 0); }
		public TerminalNode EXISTS() { return getToken(PaimonSqlExtensionsParser.EXISTS, 0); }
		public TerminalNode HOURS() { return getToken(PaimonSqlExtensionsParser.HOURS, 0); }
		public TerminalNode IF() { return getToken(PaimonSqlExtensionsParser.IF, 0); }
		public TerminalNode NOT() { return getToken(PaimonSqlExtensionsParser.NOT, 0); }
		public TerminalNode OF() { return getToken(PaimonSqlExtensionsParser.OF, 0); }
		public TerminalNode OR() { return getToken(PaimonSqlExtensionsParser.OR, 0); }
		public TerminalNode TABLE() { return getToken(PaimonSqlExtensionsParser.TABLE, 0); }
		public TerminalNode REPLACE() { return getToken(PaimonSqlExtensionsParser.REPLACE, 0); }
		public TerminalNode RETAIN() { return getToken(PaimonSqlExtensionsParser.RETAIN, 0); }
		public TerminalNode VERSION() { return getToken(PaimonSqlExtensionsParser.VERSION, 0); }
		public TerminalNode TAG() { return getToken(PaimonSqlExtensionsParser.TAG, 0); }
		public TerminalNode TRUE() { return getToken(PaimonSqlExtensionsParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(PaimonSqlExtensionsParser.FALSE, 0); }
		public TerminalNode MAP() { return getToken(PaimonSqlExtensionsParser.MAP, 0); }
		public NonReservedContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nonReserved; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).enterNonReserved(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PaimonSqlExtensionsListener ) ((PaimonSqlExtensionsListener)listener).exitNonReserved(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PaimonSqlExtensionsVisitor ) return ((PaimonSqlExtensionsVisitor<? extends T>)visitor).visitNonReserved(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NonReservedContext nonReserved() throws RecognitionException {
		NonReservedContext _localctx = new NonReservedContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_nonReserved);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(216);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ALTER) | (1L << AS) | (1L << CALL) | (1L << CREATE) | (1L << DAYS) | (1L << DELETE) | (1L << EXISTS) | (1L << HOURS) | (1L << IF) | (1L << NOT) | (1L << OF) | (1L << OR) | (1L << REPLACE) | (1L << RETAIN) | (1L << TABLE) | (1L << TAG) | (1L << VERSION) | (1L << TRUE) | (1L << FALSE) | (1L << MAP))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\63\u00dd\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\3\2\3\2\7\2\'\n\2\f\2\16\2*\13\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\7\3"+
		"\64\n\3\f\3\16\3\67\13\3\5\39\n\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3L\n\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\5\3Y\n\3\3\4\3\4\3\4\3\4\3\4\5\4`\n\4\3\5\3\5\3\5\3\5"+
		"\3\5\5\5g\n\5\3\5\3\5\3\5\3\5\3\5\5\5n\n\5\3\5\3\5\3\5\3\5\3\5\5\5u\n"+
		"\5\3\6\3\6\3\6\3\6\5\6{\n\6\3\6\5\6~\n\6\3\7\3\7\3\b\3\b\3\b\3\b\3\t\3"+
		"\t\3\n\3\n\5\n\u008a\n\n\3\13\3\13\3\13\6\13\u008f\n\13\r\13\16\13\u0090"+
		"\3\13\3\13\3\13\5\13\u0096\n\13\3\f\3\f\3\f\3\f\3\f\7\f\u009d\n\f\f\f"+
		"\16\f\u00a0\13\f\3\f\3\f\3\r\3\r\3\16\5\16\u00a7\n\16\3\16\3\16\5\16\u00ab"+
		"\n\16\3\16\3\16\5\16\u00af\n\16\3\16\3\16\5\16\u00b3\n\16\3\16\3\16\5"+
		"\16\u00b7\n\16\3\16\3\16\5\16\u00bb\n\16\3\16\3\16\5\16\u00bf\n\16\3\16"+
		"\3\16\5\16\u00c3\n\16\3\16\3\16\5\16\u00c7\n\16\3\16\5\16\u00ca\n\16\3"+
		"\17\3\17\3\17\7\17\u00cf\n\17\f\17\16\17\u00d2\13\17\3\20\3\20\3\20\5"+
		"\20\u00d7\n\20\3\21\3\21\3\22\3\22\3\22\2\2\23\2\4\6\b\n\f\16\20\22\24"+
		"\26\30\32\34\36 \"\2\5\5\2\r\r\20\20\22\22\3\2\37 \7\2\t\21\23\25\27\30"+
		"\32\33\36!\2\u00f3\2$\3\2\2\2\4X\3\2\2\2\6_\3\2\2\2\bt\3\2\2\2\nz\3\2"+
		"\2\2\f\177\3\2\2\2\16\u0081\3\2\2\2\20\u0085\3\2\2\2\22\u0089\3\2\2\2"+
		"\24\u0095\3\2\2\2\26\u0097\3\2\2\2\30\u00a3\3\2\2\2\32\u00c9\3\2\2\2\34"+
		"\u00cb\3\2\2\2\36\u00d6\3\2\2\2 \u00d8\3\2\2\2\"\u00da\3\2\2\2$(\5\4\3"+
		"\2%\'\7\3\2\2&%\3\2\2\2\'*\3\2\2\2(&\3\2\2\2()\3\2\2\2)+\3\2\2\2*(\3\2"+
		"\2\2+,\7\2\2\3,\3\3\2\2\2-.\7\13\2\2./\5\34\17\2/8\7\4\2\2\60\65\5\6\4"+
		"\2\61\62\7\5\2\2\62\64\5\6\4\2\63\61\3\2\2\2\64\67\3\2\2\2\65\63\3\2\2"+
		"\2\65\66\3\2\2\2\669\3\2\2\2\67\65\3\2\2\28\60\3\2\2\289\3\2\2\29:\3\2"+
		"\2\2:;\7\6\2\2;Y\3\2\2\2<=\7\31\2\2=>\7\34\2\2>Y\5\34\17\2?@\7\t\2\2@"+
		"A\7\32\2\2AB\5\34\17\2BC\5\b\5\2CY\3\2\2\2DE\7\t\2\2EF\7\32\2\2FG\5\34"+
		"\17\2GH\7\16\2\2HK\7\33\2\2IJ\7\21\2\2JL\7\17\2\2KI\3\2\2\2KL\3\2\2\2"+
		"LM\3\2\2\2MN\5\36\20\2NY\3\2\2\2OP\7\t\2\2PQ\7\32\2\2QR\5\34\17\2RS\7"+
		"\26\2\2ST\7\33\2\2TU\5\36\20\2UV\7\35\2\2VW\5\36\20\2WY\3\2\2\2X-\3\2"+
		"\2\2X<\3\2\2\2X?\3\2\2\2XD\3\2\2\2XO\3\2\2\2Y\5\3\2\2\2Z`\5\22\n\2[\\"+
		"\5\36\20\2\\]\7\7\2\2]^\5\22\n\2^`\3\2\2\2_Z\3\2\2\2_[\3\2\2\2`\7\3\2"+
		"\2\2ab\7\f\2\2bf\7\33\2\2cd\7\21\2\2de\7\23\2\2eg\7\17\2\2fc\3\2\2\2f"+
		"g\3\2\2\2gh\3\2\2\2hi\5\36\20\2ij\5\n\6\2ju\3\2\2\2kl\7\f\2\2ln\7\25\2"+
		"\2mk\3\2\2\2mn\3\2\2\2no\3\2\2\2op\7\27\2\2pq\7\33\2\2qr\5\36\20\2rs\5"+
		"\n\6\2su\3\2\2\2ta\3\2\2\2tm\3\2\2\2u\t\3\2\2\2vw\7\n\2\2wx\7\24\2\2x"+
		"y\7\36\2\2y{\5\f\7\2zv\3\2\2\2z{\3\2\2\2{}\3\2\2\2|~\5\16\b\2}|\3\2\2"+
		"\2}~\3\2\2\2~\13\3\2\2\2\177\u0080\5\32\16\2\u0080\r\3\2\2\2\u0081\u0082"+
		"\7\30\2\2\u0082\u0083\5\32\16\2\u0083\u0084\5\20\t\2\u0084\17\3\2\2\2"+
		"\u0085\u0086\t\2\2\2\u0086\21\3\2\2\2\u0087\u008a\5\24\13\2\u0088\u008a"+
		"\5\26\f\2\u0089\u0087\3\2\2\2\u0089\u0088\3\2\2\2\u008a\23\3\2\2\2\u008b"+
		"\u0096\5\32\16\2\u008c\u0096\5\30\r\2\u008d\u008f\7$\2\2\u008e\u008d\3"+
		"\2\2\2\u008f\u0090\3\2\2\2\u0090\u008e\3\2\2\2\u0090\u0091\3\2\2\2\u0091"+
		"\u0096\3\2\2\2\u0092\u0093\5\36\20\2\u0093\u0094\7$\2\2\u0094\u0096\3"+
		"\2\2\2\u0095\u008b\3\2\2\2\u0095\u008c\3\2\2\2\u0095\u008e\3\2\2\2\u0095"+
		"\u0092\3\2\2\2\u0096\25\3\2\2\2\u0097\u0098\7!\2\2\u0098\u0099\7\4\2\2"+
		"\u0099\u009e\5\24\13\2\u009a\u009b\7\5\2\2\u009b\u009d\5\24\13\2\u009c"+
		"\u009a\3\2\2\2\u009d\u00a0\3\2\2\2\u009e\u009c\3\2\2\2\u009e\u009f\3\2"+
		"\2\2\u009f\u00a1\3\2\2\2\u00a0\u009e\3\2\2\2\u00a1\u00a2\7\6\2\2\u00a2"+
		"\27\3\2\2\2\u00a3\u00a4\t\3\2\2\u00a4\31\3\2\2\2\u00a5\u00a7\7#\2\2\u00a6"+
		"\u00a5\3\2\2\2\u00a6\u00a7\3\2\2\2\u00a7\u00a8\3\2\2\2\u00a8\u00ca\7)"+
		"\2\2\u00a9\u00ab\7#\2\2\u00aa\u00a9\3\2\2\2\u00aa\u00ab\3\2\2\2\u00ab"+
		"\u00ac\3\2\2\2\u00ac\u00ca\7*\2\2\u00ad\u00af\7#\2\2\u00ae\u00ad\3\2\2"+
		"\2\u00ae\u00af\3\2\2\2\u00af\u00b0\3\2\2\2\u00b0\u00ca\7(\2\2\u00b1\u00b3"+
		"\7#\2\2\u00b2\u00b1\3\2\2\2\u00b2\u00b3\3\2\2\2\u00b3\u00b4\3\2\2\2\u00b4"+
		"\u00ca\7%\2\2\u00b5\u00b7\7#\2\2\u00b6\u00b5\3\2\2\2\u00b6\u00b7\3\2\2"+
		"\2\u00b7\u00b8\3\2\2\2\u00b8\u00ca\7&\2\2\u00b9\u00bb\7#\2\2\u00ba\u00b9"+
		"\3\2\2\2\u00ba\u00bb\3\2\2\2\u00bb\u00bc\3\2\2\2\u00bc\u00ca\7\'\2\2\u00bd"+
		"\u00bf\7#\2\2\u00be\u00bd\3\2\2\2\u00be\u00bf\3\2\2\2\u00bf\u00c0\3\2"+
		"\2\2\u00c0\u00ca\7,\2\2\u00c1\u00c3\7#\2\2\u00c2\u00c1\3\2\2\2\u00c2\u00c3"+
		"\3\2\2\2\u00c3\u00c4\3\2\2\2\u00c4\u00ca\7+\2\2\u00c5\u00c7\7#\2\2\u00c6"+
		"\u00c5\3\2\2\2\u00c6\u00c7\3\2\2\2\u00c7\u00c8\3\2\2\2\u00c8\u00ca\7-"+
		"\2\2\u00c9\u00a6\3\2\2\2\u00c9\u00aa\3\2\2\2\u00c9\u00ae\3\2\2\2\u00c9"+
		"\u00b2\3\2\2\2\u00c9\u00b6\3\2\2\2\u00c9\u00ba\3\2\2\2\u00c9\u00be\3\2"+
		"\2\2\u00c9\u00c2\3\2\2\2\u00c9\u00c6\3\2\2\2\u00ca\33\3\2\2\2\u00cb\u00d0"+
		"\5\36\20\2\u00cc\u00cd\7\b\2\2\u00cd\u00cf\5\36\20\2\u00ce\u00cc\3\2\2"+
		"\2\u00cf\u00d2\3\2\2\2\u00d0\u00ce\3\2\2\2\u00d0\u00d1\3\2\2\2\u00d1\35"+
		"\3\2\2\2\u00d2\u00d0\3\2\2\2\u00d3\u00d7\7.\2\2\u00d4\u00d7\5 \21\2\u00d5"+
		"\u00d7\5\"\22\2\u00d6\u00d3\3\2\2\2\u00d6\u00d4\3\2\2\2\u00d6\u00d5\3"+
		"\2\2\2\u00d7\37\3\2\2\2\u00d8\u00d9\7/\2\2\u00d9!\3\2\2\2\u00da\u00db"+
		"\t\4\2\2\u00db#\3\2\2\2\35(\658KX_fmtz}\u0089\u0090\u0095\u009e\u00a6"+
		"\u00aa\u00ae\u00b2\u00b6\u00ba\u00be\u00c2\u00c6\u00c9\u00d0\u00d6";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}