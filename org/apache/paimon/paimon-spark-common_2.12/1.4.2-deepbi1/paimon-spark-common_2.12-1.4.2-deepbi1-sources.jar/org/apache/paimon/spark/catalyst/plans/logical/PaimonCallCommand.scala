/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.spark.catalyst.plans.logical

import org.apache.paimon.spark.leafnode.PaimonLeafCommand
import org.apache.paimon.spark.procedure.Procedure

import org.apache.spark.sql.catalyst.expressions.{Attribute, AttributeReference, Expression}
import org.apache.spark.sql.catalyst.util.truncatedString

/** A CALL command that resolves stored procedure from SQL. */
case class PaimonCallCommand(procedure: Procedure, args: Seq[Expression])
  extends PaimonLeafCommand {

  override lazy val output: Seq[Attribute] =
    procedure.outputType.map(
      field => AttributeReference(field.name, field.dataType, field.nullable, field.metadata)())

  override def simpleString(maxFields: Int): String = {
    s"Call${truncatedString(output, "[", ", ", "]", maxFields)} ${procedure.description}"
  }
}
