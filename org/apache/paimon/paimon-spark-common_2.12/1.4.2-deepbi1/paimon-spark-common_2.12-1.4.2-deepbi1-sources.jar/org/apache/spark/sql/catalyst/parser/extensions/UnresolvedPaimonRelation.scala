/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.spark.sql.catalyst.parser.extensions

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.analysis.{EliminateSubqueryAliases, UnresolvedTable}
import org.apache.spark.sql.catalyst.plans.logical.LogicalPlan
import org.apache.spark.sql.connector.catalog.{PaimonLookupCatalog, TableCatalog}

import scala.util.Try

object UnresolvedPaimonRelation extends PaimonLookupCatalog {
  protected lazy val catalogManager = SparkSession.active.sessionState.catalogManager

  def unapply(plan: LogicalPlan): Option[LogicalPlan] = {
    EliminateSubqueryAliases(plan) match {
      case UnresolvedTable(multipartIdentifier, _, _) if isPaimonTable(multipartIdentifier) =>
        Some(plan)
      case _ => None
    }
  }

  private def isPaimonTable(multipartIdentifier: Seq[String]): Boolean = {
    multipartIdentifier match {
      case CatalogAndIdentifier(catalog: TableCatalog, ident) =>
        Try(catalog.loadTable(ident))
          .map(t => t.isInstanceOf[org.apache.paimon.spark.SparkTable])
          .getOrElse(false)
      case _ => false
    }
  }

}
