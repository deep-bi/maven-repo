/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.operation.commit;

import org.apache.paimon.Snapshot;
import org.apache.paimon.catalog.TableRollback;
import org.apache.paimon.table.Instant;

/** Commit rollback to rollback 'COMPACT' commits for resolving conflicts. */
public class CommitRollback {

    private final TableRollback tableRollback;

    public CommitRollback(TableRollback tableRollback) {
        this.tableRollback = tableRollback;
    }

    public boolean tryToRollback(Snapshot latestSnapshot) {
        if (latestSnapshot.commitKind() == Snapshot.CommitKind.COMPACT) {
            long latest = latestSnapshot.id();
            try {
                tableRollback.rollbackTo(Instant.snapshot(latest - 1), latest);
                return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }
}
