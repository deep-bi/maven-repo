/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.append.cluster;

import org.apache.paimon.CoreOptions;
import org.apache.paimon.codegen.CodeGenUtils;
import org.apache.paimon.data.InternalRow;
import org.apache.paimon.data.JoinedRow;
import org.apache.paimon.disk.IOManager;
import org.apache.paimon.reader.RecordReaderIterator;
import org.apache.paimon.types.RowType;
import org.apache.paimon.utils.Projection;

import java.util.List;

import static org.apache.paimon.table.PrimaryKeyTableUtils.addKeyNamePrefix;

/** Order sorter for clustering. */
public class OrderSorter extends Sorter {

    private final OrderKeyAbstract orderKeyAbstract;

    public OrderSorter(
            RecordReaderIterator<InternalRow> reader,
            RowType valueType,
            CoreOptions options,
            List<String> orderColNames,
            IOManager ioManager) {
        super(reader, keyType(valueType, orderColNames), valueType, options, ioManager);
        this.orderKeyAbstract = new OrderKeyAbstract(valueType, orderColNames);
        this.orderKeyAbstract.open();
    }

    @Override
    public InternalRow assignSortKey(InternalRow row) {
        InternalRow key = orderKeyAbstract.apply(row);
        return new JoinedRow(key, row);
    }

    private static RowType keyType(RowType valueType, List<String> orderColNames) {
        List<String> fieldNames = valueType.getFieldNames();
        int[] keyProjectionMap = orderColNames.stream().mapToInt(fieldNames::indexOf).toArray();
        return addKeyNamePrefix(Projection.of(keyProjectionMap).project(valueType));
    }

    private static class OrderKeyAbstract implements KeyAbstract<InternalRow> {

        private final RowType valueRowType;
        private final int[] keyProjectionMap;

        private transient org.apache.paimon.codegen.Projection keyProjection;

        public OrderKeyAbstract(RowType rowType, List<String> orderColNames) {
            this.valueRowType = rowType;
            List<String> fieldNames = rowType.getFieldNames();
            this.keyProjectionMap = orderColNames.stream().mapToInt(fieldNames::indexOf).toArray();
        }

        @Override
        public void open() {
            // use key gen to speed up projection
            keyProjection = CodeGenUtils.newProjection(valueRowType, keyProjectionMap);
        }

        @Override
        public InternalRow apply(InternalRow value) {
            return keyProjection.apply(value).copy();
        }
    }
}
