/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.paimon.flink.utils;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.util.Arrays;
import java.util.Collection;

/** Utility methods about {@link StreamExecutionEnvironment} to resolve compatibility issues. */
public class StreamExecutionEnvironmentUtils {

    @SafeVarargs
    public static <T> DataStreamSource<T> fromData(
            StreamExecutionEnvironment env, TypeInformation<T> typeInfo, T... data) {
        return env.fromCollection(Arrays.asList(data), typeInfo);
    }

    public static <T> DataStreamSource<T> fromData(
            StreamExecutionEnvironment env, Collection<T> data, TypeInformation<T> typeInfo) {
        return env.fromCollection(data, typeInfo);
    }
}
